package rules;

import java.util.*;
import java.io.*;
import java.util.regex.*;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;


import org.nuiton.math.matrix.*;

import fr.ifremer.isisfish.simulator.SimulationContext;
import fr.ifremer.isisfish.rule.AbstractRule;
import fr.ifremer.isisfish.annotations.Doc;
import fr.ifremer.isisfish.entities.*;
import fr.ifremer.isisfish.types.*;

import scripts.SiMatrix;
import static scripts.PTAtoolbox.expandEnvirVar;

/**
 * Forcage nb vessels, prop_vessels, inactivity et prop_str_met_month
 * 2015-2022
 * Forcage prop_str_met_month
 * 2015-2018
 *
 *  projet Macco
 *
 * doit s'appliquer avec le forcage des parametres annuels calibrés
 *
 *  Stephanie Mahevas 2023
 * -
 *     lecture d'un fichier par annee
 *
 *  
 *     
 */
public class ForcageEffort_SaufPropStr_2015_2022_MACCO extends AbstractRule {

	
	/** to use log facility, just put in your code: log.info("..."); */
    private static Log log = LogFactory.getLog(ForcageEffort_SaufPropStr_2015_2022_MACCO.class);
    
	public String param_README = String.join(" ►►► ",
					"adaptation macco : Stephanie M 2023 "
			
	);

	public static String param_cheminFichierAverage = "${PBS_O_WORKDIR}/forcage/" ;
   // public static String param_cheminFichierAverage = "C:/Users/smahevas/C-ISISFish/AppliBobMerluSoleLangoustinePlus4esp/forcage/";
    //public static String param_cheminFichierAverage = "G:/AppliBobMerluSoleLangoustinePlus4esp/forcage/";
    public static String param_cheminFichierInactivity = "inactivite/years/";
    public static String param_cheminFichierEffortProp = "str_prop_met/years/";
	//public static String param_InactivityFileName = "Total.Inactivite.effort.csv";
	//public static String param_nbVessFileName = "Total.NbBateau.effort.csv";
    public static String param_cheminFichierNbVessSov = "nb_vessels/years/";
    public static String param_cheminFichierPropNbVess = "nb_prop_vessels/years/";
	//public static String param_EffortPropFileName = "Total.Proportion.strategy.csv";
   
	
	@Doc(value = "simulation starting year compared to estimation starting year (0: 2015; 1: 2016; 2: 2017; 3: 2018; 4:2019; 5:2020; 6:2021; 7:2022; 8: 2023)")
	public int param_startDate = 8;
    
    @Doc(value = "After 2018: true = mean effort 2010-22, false = effort 2018)")
    public boolean param_averagefrom2010 = false;
 
    //public int param_endDate = 0;
    private int param_year = 2015 + param_startDate; //annee de debut

	private List<Strategy> allStrategies;
    private List<Metier> allMetiers;
    private List<SetOfVessels> allSetOfVessels;
	private MatrixND matInactivity; //anneexstr
	private MatrixND matEffort; //anneexstrxmetierxmois
	private MatrixND matNbVessSov; //anneexsov
    private MatrixND matPropVess; //anneexstr

    Pattern ForeignPattern = Pattern.compile("^(ES|UK|BE)"); //pour les flottilles/str etrangeres on ne change pas nb_vessels=1 et prop_vessells=1
	private boolean first = true; // ne boucler que sur un seul métier dans la préaction :

	public String[] necessaryResult = {}; // must be initialized, error if not
	public String[] getNecessaryResult() { return this.necessaryResult; }

	/** Permet d’afficher à l’utilisateur une aide sur la règle */
	public String getDescription() {
		return "Forcage nb vessels, prop_vessels, inactivity et prop_str_met_month sur 2015-2022 et Forcage prop_str_met_month 2015-2018, puis valeurs de la dernière annee disponible ou moyenne";
	}

    protected List<SetOfVessels> getSetOfVessels(List<Strategy> strategies) {
        List<SetOfVessels> setOfVessels = new ArrayList<>();
        Set<SetOfVessels> tmp = new HashSet<>();
        for (Strategy str : strategies) {
            SetOfVessels sov = str.getSetOfVessels();
            if (tmp.add(sov)) {
                setOfVessels.add(sov);
            }
        }
        return setOfVessels;
    }
    
	/**
	 * Appelée au démarrage de la simulation, cette méthode permet d’initialiser des valeurs.
	 *
	 * @param context la simulation pour lequel on utilise cette règle
	 */
	public void init(SimulationContext context) throws Exception {

		// récupération des set of vessels, stratégies
		SiMatrix siMatrix = SiMatrix.getSiMatrix(context);
		TimeStep step = new TimeStep(0);

		// récupération des stratégies
		allStrategies = siMatrix.getStrategies(step);
		allMetiers = siMatrix.getMetiers(step);
        allSetOfVessels = getSetOfVessels(allStrategies);
		List<Month>allMonths=Arrays.asList(Month.MONTH);
        

        // (0: 2015; 1: 2016; 2: 2017; 3: 2018; 4:2019; 5:2020; 6:2021; 7:2022; 8 average 2010-22 or 2022)")
        //List<Integer> annees = List.of(0, 1, 2, 3, 4);
		List<Integer> annees = List.of(0, 1, 2, 3,4,5,6,7);
		List<Integer> anneesRed = List.of(0, 1, 2, 3);
        // init all matrix
        matInactivity = MatrixFactory.getInstance().create(
                "matInactivity", new List[] { annees, allStrategies, allMonths },
                new String[] { "Annee", "Strategies","Months" });
        matEffort = MatrixFactory.getInstance().create(
                "matEffort", new List[] { anneesRed, allStrategies, allMetiers, allMonths },
                new String[] { "Annee", "Strategies", "Metiers","Months" });      
        matNbVessSov = MatrixFactory.getInstance().create(
                "matNbVessSov", new List[] { annees, allSetOfVessels },
                new String[] { "Annee", "Flottille" });
        matPropVess = MatrixFactory.getInstance().create(
                "matPropVess", new List[] { annees, allStrategies },
                new String[] { "Annee", "Strategies" });

		String param_StringYear;
		//chargement dans l'init des matrices pour toutes les annnees 
		// Boucle sur les annees (year) de startDate a endDate  pour remplir les matrices
        // Import des matrices 2015,2016,2017,2018,moyenne2010-2020

       param_cheminFichierAverage = expandEnvirVar.replace(param_cheminFichierAverage);
  
        for (Integer annee : annees) {
        	param_year = 2015 + annee;
           System.out.println("---------------------- Annee =  " + param_year);
            // NEW : nb vessels de set of vessels :fichier avec semantic des setof vessels et annee de 0 =2015 à ...

			// vaut 1 pour les flottilles etrangeres
		    File nbVessSovFile = new File(param_cheminFichierAverage + param_cheminFichierNbVessSov + param_year + "_allSetofVessels.txt");
	        MatrixND matNbVessSovForYear = MatrixFactory.getInstance().create(nbVessSovFile);
            for (SetOfVessels sov : allSetOfVessels) {
                String sovName=sov.getName();
                 Matcher ForeignMatch = ForeignPattern.matcher(sovName);
                if (!ForeignMatch.find()) {
                    // if(matNbVessSovForYear.getValue(sov)==null) mettre 0 sinon remplir
                 if (matNbVessSovForYear.getSemantic(0).contains(sov)) {    
                    matNbVessSov.setValue(annee, sov, matNbVessSovForYear.getValue(sov));
                 }  
                 //else {
                 //    matNbVessSov.setValue(annee, sov, 0);
                 // }
                }
            }
		    System.out.println("matrice nb navires Set of Vessels " + matNbVessSov);


            // Inactivity - à entrer aussi pour les etrangers
			File inactivityFile = new File(param_cheminFichierAverage + param_cheminFichierInactivity + param_year + "_allStrategy.txt");
            MatrixND matInactivityForYear = MatrixFactory.getInstance().create(inactivityFile);
            for (Strategy str : allStrategies) {
                String strName = str.getName();
               // Matcher ForeignMatch = ForeignPattern.matcher(strName);
               // if (!ForeignMatch.find()) {
                for (Month month : allMonths){
                       // if(matInactivityForYear.getValue(str,month)==null) mettre 0 sinon remplir
                   if (matInactivityForYear.getSemantic(0).contains(str)) {  
                    matInactivity.setValue(annee, str, month,matInactivityForYear.getValue(str,month));
                   }
                   //else {
                   // matInactivity.setValue(annee, str, month,0);
                   //}
                //}
                }
            }
            System.out.println("matrice inactivite " + matInactivity);


            // propVess ?
			File propVessFile = new File(param_cheminFichierAverage + param_cheminFichierPropNbVess + param_year + "_allStrategy.txt"); //double nbv = matNbVess.getValue(str, ts.getYear()); donc fichier avec semantic des stratégies et annee de 0 =2015 à ...
            MatrixND matPropVessForYear = MatrixFactory.getInstance().create(propVessFile);
            for (Strategy str : allStrategies) {
                String strName = str.getName();

                Matcher ForeignMatch = ForeignPattern.matcher(strName);
                if (!ForeignMatch.find()) {
					System.out.println("strategie = " +strName);
                  if (matPropVessForYear.getSemantic(0).contains(str)) {  
                    // if matPropVessForYear.getValue(str)=null mettre 0
                   matPropVess.setValue(annee, str, matPropVessForYear.getValue(str));
                  } 
                  //else {
                  // matPropVess.setValue(annee, str, 0);  
                  // }
                }
            }
            System.out.println("matrice prop navires Set of Vessels " + matPropVess);


            // Effort - uniquement sur 2015 - 2018
			if ( annee <4 ) {
				File effortFile;
				MatrixND matEffortForYear;
				for (Strategy str : allStrategies) {
					String strName = str.getName();
					System.out.println("strategie = " + strName);
					effortFile = new File(param_cheminFichierAverage + param_cheminFichierEffortProp + param_year + "_" + str + ".txt"); // double newProp = matEffort.getValue(str, strMetier, ts); ; donc fichier avec semantic des stratégies, des metiers et annee de 0 =2015 à ...
					matEffortForYear = MatrixFactory.getInstance().create(effortFile);
					Collection<EffortDescription> strMet = str.getSetOfVessels().getPossibleMetiers();
					for (EffortDescription ed : strMet) {
						Metier met = ed.getPossibleMetiers();
						String metName = met.getName();
						System.out.println("metier = " + metName);
						for (Month month : allMonths) {
							matEffort.setValue(annee, str, met, month, matEffortForYear.getValue(met, month));
						}
					}
				}
				System.out.println("matrice effort " + matEffort);
			}
        }
	}

	/**
	 * La condition qui doit être vraie pour faire les actions.
	 *
	 * @param context la simulation pour laquelle on utilise cette règle
	 * @param step le pas de temps courant
	 * @param metier le métier concerné
	 * @return vrai si on souhaite que les actions soit faites
	 */
	public boolean condition(SimulationContext context, TimeStep step, Metier metier) { 
       
        int start = param_startDate * 12; // If startDate != 0 si debut en 2013 8*12 = 96 par rapport à 2015
        TimeStep ts = step.add(start);
        boolean beforeEndYearForcage = (ts.getStep() < 84); //84 si forcage jqu'en 2022
        if (beforeEndYearForcage){ // before  do preaction
             return true; 
        } else {
	       if (param_averagefrom2010) { 
            return false; // Do not change prop_str : on utlise la moyenne2010-2020 qui est par defaut dans la base
	       } else {
	        return true; // do preaction and use 2022 values
	       }
	    }

	}

	/** Si la condition est vraie alors cette action est exécutée avant le pas de temps de la simulation. */
	public void preAction(SimulationContext context, TimeStep step, Metier metier) {

		if (first) {
			System.out.println("Oui, preaction : ");

			// If startDate != 0
			int start = param_startDate * 12; // si on demarre en 2023 start = 8*12 = 96
			TimeStep ts = step.add(start); //time step relative to 2015
			TimeStep ts_str = step.add(start); //time step relative to 2015
         
			//if (step.getStep() + 12 > 47) ts_str = new TimeStep(ts.getMonth().getMonthNumber() + 36); // prop effort dans str à partir de 2019 = 2018
			// time step de 2018 par rapport à 2015 = 3*12 = 36, 2019 : 4*12 = 48
			if (ts.getStep() > 47) ts_str = new TimeStep(ts.getMonth().getMonthNumber() + 36); //  à partir de 2019, on simule avec valeur de prop effort dans str de  2018

			//if (step.getStep() + 12 > 59) ts = new TimeStep(ts.getMonth().getMonthNumber() + 48); // une annee de plus - ne marchera que quand on aura une moyenne
			//84 si forcage jqu'en 2022
			//72 si forcage jqu'en 2021
            //time step de 2023 par rapport à 2015 = 8*12 = 96, 2022 : 7*12 = 84
			if (ts.getStep() > 95) ts = new TimeStep(ts.getMonth().getMonthNumber() + 84); // ie à partir de 2023, on simule avec valeur de 2022
			System.out.println("Timestep : " + ts);


			//Boucle sur les Set of Vessels : a verifier
			for (SetOfVessels sovIndex : allSetOfVessels){
				String sovName=sovIndex.getName();
				System.out.println("Set of Vessels : "+sovName);

				// interdit de faire des set sur les stratégies de la sémantique de la matrice, il faut récupérer les stratégies de la date courante ?? pour sov
		        SetOfVessels sov=(SetOfVessels)context.getDB().findByTopiaId(sovIndex.getTopiaId());

				// Change vessel number
				Matcher ForeignMatch = ForeignPattern.matcher(sovName);
				if (ForeignMatch.find()) {
					System.out.println("    foreign, don’t change nb vessells");
				} else {
					int nbvSov=(int)matNbVessSov.getValue(ts.getYear(), sov);
					sovIndex.setNumberOfVessels(nbvSov);
					System.out.println("Nb bateaux : "+nbvSov);
				}
			}
			// Boucle sur les stratégies
			for (Strategy strIndex : allStrategies) {
				String strName = strIndex.getName();
				System.out.println("Strategie : " + strName);

				// interdit de faire des set sur les stratégies de la sémantique de la matrice, il faut récupérer les stratégies de la date courante
				Strategy str = (Strategy) context.getDB().findByTopiaId(strIndex.getTopiaId());

				// Change prop_vessel number
				Matcher ForeignMatch = ForeignPattern.matcher(strName);
				if (ForeignMatch.find()) {
					System.out.println("    foreign, don’t change prop vessells");
				} else {
					double nbv = matPropVess.getValue(ts.getYear(), str);
					str.setProportionSetOfVessels(nbv);
					System.out.println("Nb bateaux : " + nbv);
				}

				// Change Effort proportion
				StrategyMonthInfo smi = str.getStrategyMonthInfo(ts.getMonth());
				Collection<EffortDescription> strMet = str.getSetOfVessels().getPossibleMetiers() ;
				for (EffortDescription ed : strMet) {
					Metier strMetier = ed.getPossibleMetiers();
					double newProp = matEffort.getValue(ts_str.getYear(), str, strMetier,ts.getMonth());
					smi.setProportionMetier(strMetier,newProp);
					System.out.println("proportion : " + strMetier + " " + newProp);
					System.out.println(smi.getProportionMetier(strMetier));

				}

				// Change Inactivity équation
				double newInactivity = matInactivity.getValue(ts.getYear(), str, ts.getMonth());
				//double newInactivity = 20;
				System.out.println("newInactivity :" + newInactivity);
				Equation eqInac = str.getInactivityEquation();
				eqInac.setContent("return " + newInactivity + " ;");
				str.setInactivityEquationUsed(true) ;
				System.out.println("Inactivity :" + eqInac.getContent());

			}
			first = false;
		}

	}

	/** Si la condition est vraie alors cette action est exécutée après le pas de temps de la simulation. */
	public void postAction(SimulationContext context, TimeStep step, Metier metier) { first = true; }

}
